// pages/Users/Users.js
Page({
  onLoad: function () {

  },

  toPika: function () {
    wx.navigateTo({
      url: '../UserPika/UserPika',
    })
  },

  toDragon: function () {
    wx.navigateTo({
      url: '../UserDragon/UserDragon',
    })
  },

  toHa: function () {
    wx.navigateTo({
      url: '../UserHa/UserHa',
    })
  }

})
 