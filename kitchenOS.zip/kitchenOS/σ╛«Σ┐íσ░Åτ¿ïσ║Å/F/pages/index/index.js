//index.js
//获取应用实例
const app = getApp()

Page({
  onLoad: function () {
    
  },

  toMain: function () {
       wx.navigateTo({
        url: '../Main/Main',
      })
    },
    
  toRec: function () {
    wx.navigateTo({
      url: '../Rec/Rec',
    })
  },


    toScan: function () {
    wx.navigateTo({
      url: '../Scan/Scan',
    })
  },

  toUsers: function () {
      wx.navigateTo({
        url: '../Users/Users',
      })
    },
})
  