// pages/Rec/Rec.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    num:"",
    ppl1: "",
    ppl2:"",
    ppl3: "",
    ppl4: "",
    ppl5: ""

  },

  /**
   * 组件的方法列表
   */
  RRec: function () {
    wx.navigateTo({
      url: '../Rec/Rec',
    })

    wx.setStorage({
      num: "num",
      ppl1: "ppl1",
      ppl2: "ppl2",
      ppl3: "ppl3",
      ppl4: "ppl4",
      ppl5: "ppl5"
    })
  },

    userNameInput1: function () {
      this.setData({
        ppl1: e.detail.value
      })
  },

    userNameInput2: function () {
      this.setData({
        ppl2: e.detail.value
      })
    },

    userNameInput3: function () {
      this.setData({
        ppl3: e.detail.value
      })
    },

    userNameInput4: function () {
      this.setData({
        ppl4: e.detail.value
      })
    },
    userNameInput5: function () {
      this.setData({
        ppl5: e.detail.value
      })
    },
})
