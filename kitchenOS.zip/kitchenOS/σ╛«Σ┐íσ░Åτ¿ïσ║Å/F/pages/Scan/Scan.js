// pages/Scan/Scan.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },
  onload: function (){
  wx.scanCode({
    onlyFromCamera: true,
    success: (res) => {
      console.log(res)
    }
  })
}
 
})
